#include "mainwindow.h"
#include "ui_mainwindow.h"


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    /*ui->prgPrcnt1->setOrientation(Qt::Horizontal);
    ui->prgPrcnt1->setRange(0, 100); // Let's say it goes from 0 to 100
    ui->prgPrcnt1->setValue(100); // With a current value of 10*/
    ui->setupUi(this);
    objectTimer = new QTimer();
}

MainWindow::~MainWindow()
{
    delete ui;
    delete objectTimer;
    objectTimer=nullptr;
}

void MainWindow::on_btnStart_clicked()
{
    connect(objectTimer, SIGNAL(timeout()), this, SLOT(slotShowTimer()));
    objectTimer->start(1000);

    ui->prgPrcnt1->setOrientation(Qt::Horizontal);
    ui->prgPrcnt1->setRange(0, 100); // Let's say it goes from 0 to 100
    ui->prgPrcnt1->setValue(100); // With a current value of 10

    ui->prgPrcnt2->setOrientation(Qt::Horizontal);
    ui->prgPrcnt2->setRange(0, 100); // Let's say it goes from 0 to 100
    ui->prgPrcnt2->setValue(100); // With a current value of 10
}

void MainWindow::slotShowTimer()
{
    gametime+=1;
    player1Time+=1;
    player2Time+=1;
    qDebug()<<"Aikaa kulunut "<<gametime<<" sekuntia\n";
}

void MainWindow::on_btnStop_clicked()
{
    connect(objectTimer, SIGNAL(timeout()), this, SLOT(slotShowTimer()));
    objectTimer->stop();
}

void MainWindow::updateProgressBar()
{
    /*ui->prgPrcnt1->setOrientation(Qt::Horizontal);
    ui->prgPrcnt1->setRange(0, 100); // Let's say it goes from 0 to 100
    ui->prgPrcnt1->setValue(100); // With a current value of 10*/
}
